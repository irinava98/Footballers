﻿namespace Footballers.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-AVOU6JD\SQLEXPRESS;Database=Footballers;Trusted_Connection=True";
    }
}
